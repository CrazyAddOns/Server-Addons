plugin.video.sonyliv
================

XBMC Addon for Sony LIV Video website

Version 1.0.2 Added Next Page
Version 1.0.1 initial release

