Schaetze der Welt / Treasures of the World XBMC Addon
=======
Schaetze der Welt / Treasures of the World is an XBMC addon that gives you access to the Schaetze der Welt / Treasures of the World archive


Supported platforms
-------------------
XBMC (Linux, Windows, raspBMC, ...)


Current Features
----------------
* All episodes ordered by country


Further information
-------------------
German: www.schaetze-der-welt.de
International: www.dw.de/program/treasures-of-the-world/s-3061-9798