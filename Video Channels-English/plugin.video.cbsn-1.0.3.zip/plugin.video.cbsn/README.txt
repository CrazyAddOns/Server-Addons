plugin.video.cbsn
================

XBMC Addon for CBS News Live

Version 1.0.3 fixed feed and views
Version 1.0.2 cleaned up addon.xml
Version 1.0.1 initial release

